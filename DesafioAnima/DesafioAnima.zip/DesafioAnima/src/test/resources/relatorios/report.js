$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/features/cadastroUsuario.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#language: pt"
    }
  ],
  "line": 3,
  "name": "Cadastro de Usuário",
  "description": "  Sendo um usuário do site\n  Posso acessar o site de Automação\n  Para realizar cadastros de um novo usuário",
  "id": "cadastro-de-usuário",
  "keyword": "Funcionalidade"
});
formatter.scenarioOutline({
  "line": 11,
  "name": "Cadastrar um usuário válido",
  "description": "",
  "id": "cadastro-de-usuário;cadastrar-um-usuário-válido",
  "type": "scenario_outline",
  "keyword": "Esquema do Cenário"
});
formatter.step({
  "line": 12,
  "name": "que tenho \u003cnome\u003e, \u003csobrenome\u003e,\u003cemail\u003e,\u003cendereco\u003e,\u003cuniversidade\u003e,\u003cprofissao\u003e,\u003csexo\u003e,\u003cidade\u003e validos",
  "keyword": "E "
});
formatter.step({
  "line": 13,
  "name": "faço o cadastro",
  "keyword": "Quando "
});
formatter.step({
  "line": 14,
  "name": "eu vejo a mensagem \"Usuário Criado com sucesso\"",
  "keyword": "Então "
});
formatter.examples({
  "line": 16,
  "name": "",
  "description": "",
  "id": "cadastro-de-usuário;cadastrar-um-usuário-válido;",
  "rows": [
    {
      "cells": [
        "nome",
        "sobrenome",
        "email",
        "endereco",
        "universidade",
        "profissao",
        "sexo",
        "idade"
      ],
      "line": 17,
      "id": "cadastro-de-usuário;cadastrar-um-usuário-válido;;1"
    },
    {
      "cells": [
        "\"Fenanda\"",
        "\"Teixeira\"",
        "\"fernanda12456@gmail.com.br\"",
        "\"Rua X, 1234\"",
        "\"Unibh\"",
        "\"QA\"",
        "\"Feminino\"",
        "\"26\""
      ],
      "line": 18,
      "id": "cadastro-de-usuário;cadastrar-um-usuário-válido;;2"
    }
  ],
  "keyword": "Exemplos"
});
formatter.background({
  "line": 8,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Contexto"
});
formatter.step({
  "line": 9,
  "name": "que estou no site \"https://automacaocombatista.herokuapp.com/users/new\"",
  "keyword": "Dado "
});
formatter.match({
  "arguments": [
    {
      "val": "https://automacaocombatista.herokuapp.com/users/new",
      "offset": 19
    }
  ],
  "location": "CadUsuarioStep.que_estou_no_site(String)"
});
formatter.result({
  "duration": 27389253015,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Cadastrar um usuário válido",
  "description": "",
  "id": "cadastro-de-usuário;cadastrar-um-usuário-válido;;2",
  "type": "scenario",
  "keyword": "Esquema do Cenário"
});
formatter.step({
  "line": 12,
  "name": "que tenho \"Fenanda\", \"Teixeira\",\"fernanda12456@gmail.com.br\",\"Rua X, 1234\",\"Unibh\",\"QA\",\"Feminino\",\"26\" validos",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7
  ],
  "keyword": "E "
});
formatter.step({
  "line": 13,
  "name": "faço o cadastro",
  "keyword": "Quando "
});
formatter.step({
  "line": 14,
  "name": "eu vejo a mensagem \"Usuário Criado com sucesso\"",
  "keyword": "Então "
});
formatter.match({
  "arguments": [
    {
      "val": "Fenanda",
      "offset": 11
    },
    {
      "val": "Teixeira",
      "offset": 22
    },
    {
      "val": "fernanda12456@gmail.com.br",
      "offset": 33
    },
    {
      "val": "Rua X, 1234",
      "offset": 62
    },
    {
      "val": "Unibh",
      "offset": 76
    },
    {
      "val": "QA",
      "offset": 84
    },
    {
      "val": "Feminino",
      "offset": 89
    },
    {
      "val": "26",
      "offset": 100
    }
  ],
  "location": "CadUsuarioStep.que_Tenho_Validos(String,String,String,String,String,String,String,String)"
});
formatter.result({
  "duration": 2092188224,
  "status": "passed"
});
formatter.match({
  "location": "CadUsuarioStep.façoOCadastro()"
});
formatter.result({
  "duration": 3673070659,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Usuário Criado com sucesso",
      "offset": 20
    }
  ],
  "location": "CadUsuarioStep.euVejoAMensagem(String)"
});
formatter.result({
  "duration": 69195061,
  "status": "passed"
});
formatter.after({
  "duration": 683592350,
  "status": "passed"
});
});