package steps;


import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.Então;
import cucumber.api.java.pt.Quando;
import pages.ConfirmacaoPage;
import pages.UsuarioPage;

public class CadUsuarioStep {
	WebDriver driver = new ChromeDriver();
	
	@Dado("^que estou no site \"([^\"]*)\"$")
	public void que_estou_no_site(String site) throws Throwable {
	    driver.get(site);
	}

/*
	@Dado("^que tenho que navegar em: \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void que_tenho_que_navegar_em(String comecarAutomacao, String linkFormulario, String listaUsuarios, String novoUsuario) throws Throwable {
		// os links são: "COMEÇAR AUTOMAÇÃO WEB","Formulário","Lista de Usuários","NOVO USUÁRIO"
		new NavegacaoPage(driver).executaCliques(comecarAutomacao, linkFormulario, listaUsuarios, novoUsuario);
	}
*/	 
	@Dado("^que tenho \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" validos$")
	public void que_Tenho_Validos(String nome, String ultimoNome, String email, String endereco, String universidade,String profissao,String sexo,String idade) throws Throwable {
	    //new UsuarioPage(driver).preencheCampos(nome, ultimoNome, email, endereco, universidade, idade, sexo, profissao);
	    
	     new UsuarioPage(driver)
	    .preencheNome(nome)
	    .preencheSobreNome(ultimoNome)
	    .preencheEmail(email)
	    .preencheEndereco(endereco)
	    .preencheUniversidade(universidade)
	    .preencheProfissao(profissao)
	    .preencheSexo(sexo)
	    .preencheIdade(idade);
	    
	}

	@Quando("^faço o cadastro$")
	public void façoOCadastro() throws Throwable {
		new UsuarioPage(driver).clicaConfirmaCadastro();
	}

	@Então("^eu vejo a mensagem \"([^\"]*)\"$")
	public void euVejoAMensagem(String msg) throws Throwable {
	    String mensagemSistema;
	    mensagemSistema= new ConfirmacaoPage(driver).retornaMensagem();
	    Assert.assertEquals("ERRO: Não veio a mensagem desejada", msg, mensagemSistema);
	    //"ERRO: Não veio a mensagem desejada", msg, mensagemSistema
	}

	@After
	public void fechaBrowser(){
		driver.quit();
	}
}
