package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class NavegacaoPage extends BasePage {

	public NavegacaoPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	public UsuarioPage clicaLink(String link){
		aguardaCarregarElemento(By.linkText(link)).click();
		return new UsuarioPage(driver);
	}
	public UsuarioPage clicaLink2(String link){
		aguardaCarregarElemento(By.cssSelector("ul>li>a[href='/users']")).click();
		return new UsuarioPage(driver);
	}	
	public UsuarioPage executaCliques(String comecarAutomacao,String linkFormulario,String listaUsuarios,String novoUsuario){ 
		clicaLink(comecarAutomacao);	
		clicaLink(linkFormulario);	
		clicaLink2(listaUsuarios); //Este exemplo pega o "Lista de Usuários", só que usando Jquery
		clicaLink(novoUsuario);
		return new UsuarioPage(driver);
	}
}
