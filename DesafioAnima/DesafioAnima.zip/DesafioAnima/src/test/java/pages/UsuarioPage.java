package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class UsuarioPage extends BasePage{

	public UsuarioPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public UsuarioPage preencheNome(String nome){
		aguardaCarregarElemento(By.id("user_name")).sendKeys(nome);
		return this;
	}
	public UsuarioPage preencheSobreNome(String ultimoNome){
		aguardaCarregarElemento(By.id("user_lastname")).sendKeys(ultimoNome);	
		return this;
	}
	public UsuarioPage preencheEmail(String email){
		aguardaCarregarElemento(By.id("user_email")).sendKeys(email);	
		return this;
	}
	public UsuarioPage preencheEndereco(String endereco){
		aguardaCarregarElemento(By.id("user_address")).sendKeys(endereco);	
		return this;
	}
	
	public UsuarioPage preencheUniversidade(String universidade){
		aguardaCarregarElemento(By.id("user_university")).sendKeys(universidade);	
		return this;
	}

	public UsuarioPage preencheIdade(String idade){
		aguardaCarregarElemento(By.id("user_age")).sendKeys(idade);	
		return this;
	}

	public UsuarioPage preencheSexo(String sexo){
		aguardaCarregarElemento(By.id("user_gender")).sendKeys(sexo);	
		return this;
	}

	public UsuarioPage preencheProfissao(String profissao){
		aguardaCarregarElemento(By.id("user_profile")).sendKeys(profissao);	
		return this;
	}

	public ConfirmacaoPage clicaConfirmaCadastro(){
		aguardaCarregarElemento(By.name("commit")).click();
		return new ConfirmacaoPage(driver);
	}
	
	public UsuarioPage preencheCampos(String nome, String ultimoNome, String email, String endereco, String universidade, String idade, String sexo, String profissao){
//		aguardaCarregarElemento(By.id("user_name")).sendKeys(nome);
		aguardaCarregarElemento(By.cssSelector("input[name*=\"[name]\"]")).sendKeys(nome);
		aguardaCarregarElemento(By.id("user_lastname")).sendKeys(ultimoNome);
		aguardaCarregarElemento(By.id("user_email")).sendKeys(email);
		aguardaCarregarElemento(By.id("user_address")).sendKeys(endereco);
		aguardaCarregarElemento(By.id("user_university")).sendKeys(universidade);
		aguardaCarregarElemento(By.id("user_age")).sendKeys(idade);
		aguardaCarregarElemento(By.id("user_gender")).sendKeys(sexo);
		aguardaCarregarElemento(By.id("user_profile")).sendKeys(profissao);
		
		return this;
	}
}
